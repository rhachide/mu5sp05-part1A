# lab3
commandes shell de base
